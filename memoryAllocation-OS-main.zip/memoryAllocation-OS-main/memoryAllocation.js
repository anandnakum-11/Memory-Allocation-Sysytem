let ana = [];
let holes = [];
let cpyHoles = [];
let processes = [];
let notComplete = [];
let currentStep = 0;
let chart = "";
let chart2 = "";
let chart3 = "";
let chart4 = "";

let chart5 = "";
let comparisonChart = null;
let simulationActive = false;
let animationSpeed = 800;
let currentAlgo = "ff";

document.addEventListener( 'DOMContentLoaded', function ()
{
    initializeTabs();
    initializeAlgoTabs();
    setDefaultValues();
    setupEventListeners();
} );

function initializeTabs()
{
    const tabBtns = document.querySelectorAll( '.tab-btn' );
    const tabContents = document.querySelectorAll( '.tab-content' );

    tabBtns.forEach( btn =>
    {
        btn.addEventListener( 'click', () =>
        {
            tabBtns.forEach( b => b.classList.remove( 'active' ) );
            tabContents.forEach( c => c.classList.remove( 'active' ) );

            btn.classList.add( 'active' );
            document.getElementById( btn.dataset.tab ).classList.add( 'active' );
        } );
    } );
}

function initializeAlgoTabs()
{
    const algoTabs = document.querySelectorAll( '.algo-tab' );
    const algoContents = document.querySelectorAll( '.algo-content' );

    algoTabs.forEach( tab =>
    {
        tab.addEventListener( 'click', () =>
        {
            algoTabs.forEach( t => t.classList.remove( 'active' ) );
            algoContents.forEach( c => c.classList.remove( 'active' ) );

            tab.classList.add( 'active' );
            currentAlgo = tab.dataset.algo;
            document.getElementById( `${tab.dataset.algo}-content` ).classList.add( 'active' );
        } );
    } );
}

function setDefaultValues()
{
    document.getElementById( 'nholes' ).value = 3;
}

function setupEventListeners()
{
    document.getElementById( 'save' ).addEventListener( 'click', saveDataHole );
    document.getElementById( 'processesInput' ).addEventListener( 'click', saveDataProcess );
}

function showToast( message, type = 'info' )
{
    const toast = document.createElement( 'div' );
    toast.className = `toast ${type}`;
    toast.innerHTML = `
        <div class="toast-icon">
            <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
        </div>
        <div class="toast-message">${message}</div>
    `;

    document.getElementById( 'toast-container' ).appendChild( toast );

    setTimeout( () =>
    {
        toast.classList.add( 'show' );
    }, 10 );

    setTimeout( () =>
    {
        toast.classList.remove( 'show' );
        setTimeout( () =>
        {
            document.getElementById( 'toast-container' ).removeChild( toast );
        }, 300 );
    }, 3000 );
}

function showModal( title, content, onConfirm )
{
    const modal = document.getElementById( 'modal-overlay' );
    const modalTitle = document.getElementById( 'modal-title' );
    const modalBody = document.getElementById( 'modal-body' );
    const modalConfirm = document.getElementById( 'modal-confirm' );
    const modalClose = document.getElementById( 'modal-close' );
    const modalCancel = document.getElementById( 'modal-cancel' );

    modalTitle.textContent = title;
    modalBody.innerHTML = content;

    modal.classList.remove( 'hidden' );

    const closeModal = () =>
    {
        modal.classList.add( 'hidden' );
    };

    modalClose.onclick = closeModal;
    modalCancel.onclick = closeModal;

    modalConfirm.onclick = () =>
    {
        if ( onConfirm ) onConfirm();
        closeModal();
    };
}

function displayInputTable()
{
    let size = parseInt( document.getElementById( 'nholes' ).value );

    if ( size <= 0 || size > 10 )
    {
        showToast( 'Please enter a number between 1 and 10', 'error' );
        return;
    }

    let table = `<table class="data-table">
        <thead>
            <tr>
                <th>Hole ID</th>
                <th>Hole Size (KB)</th>
            </tr>
        </thead>
        <tbody>`;

    for ( let i = 0; i < size; i++ )
    {
        table += `<tr class="fade-in" style="animation-delay: ${i * 0.1}s">
            <td class="td">H${i + 1}</td>
            <td><input type="number" min="1" id="holeSize${i + 1}" placeholder="Size in KB"></td>
        </tr>`;
    }

    table += `</tbody></table>`;

    document.getElementById( 'inputTable' ).innerHTML = table;

    const saveData = `<button class="btn primary">
        <i class="fas fa-save"></i> Save Holes Data
    </button>`;

    document.getElementById( 'save' ).innerHTML = saveData;
    document.getElementById( 'save' ).classList.add( 'fade-in' );

    showToast( 'Memory holes table created successfully!', 'success' );
}

function saveDataHole()
{
    const size = parseInt( document.getElementById( 'nholes' ).value );

    let isValid = true;
    let invalidFields = [];

    holes = [];
    chart = `<div class="memory-blocks">`;

    for ( let i = 0; i < size; i++ )
    {
        const sizeInput = document.getElementById( `holeSize${i + 1}` );
        const holeSize = parseInt( sizeInput.value );

        if ( isNaN( holeSize ) || holeSize <= 0 )
        {
            isValid = false;
            invalidFields.push( `H${i + 1}` );
            sizeInput.classList.add( 'error' );
        } else
        {
            sizeInput.classList.remove( 'error' );

            let hole = {};
            hole.holeId = "H" + ( i + 1 );
            hole.holeSize = holeSize;
            holes.push( hole );

            chart += `<div class="memory-block fade-in" style="animation-delay: ${i * 0.15}s">
                <div class="hole" id="initialHole${i + 1}">${holeSize} KB</div>
                <div class="hole-id">H${i + 1}</div>
            </div>`;

            if ( i != size - 1 ) chart += `<div class="memory-separator">•••</div>`;
        }
    }

    chart += `</div>`;

    if ( !isValid )
    {
        showToast( `Please enter valid sizes for holes: ${invalidFields.join( ', ' )}`, 'error' );
        return;
    }

    document.getElementById( 'gainchart' ).innerHTML = chart;
    document.querySelectorAll( '#gainchart .memory-block' ).forEach( block =>
    {
        block.classList.add( 'appear' );
    } );

    cpyHoles = JSON.parse( JSON.stringify( holes ) );

    document.getElementById( 'processSetup' ).classList.remove( 'hidden' );

    let process = `
    <div class="input-group">
        <label for="nprocesses">Number of Processes:</label>
        <div class="number-input">
            <button onclick="this.parentNode.querySelector('input').stepDown()"><i class="fas fa-minus"></i></button>
            <input type="number" min="1" max="10" value="3" id="nprocesses">
            <button onclick="this.parentNode.querySelector('input').stepUp()"><i class="fas fa-plus"></i></button>
        </div>
        <button id="inputButton" class="btn primary" onclick="displayTable()">
            <i class="fas fa-table"></i> Generate Process Table
        </button>
    </div>`;

    document.getElementById( 'processInput' ).innerHTML = process;
    showToast( 'Memory holes saved successfully!', 'success' );

    const tabBtns = document.querySelectorAll( '.tab-btn' );
    setTimeout( () =>
    {
        document.querySelector( '[data-tab="visualization"]' ).click();
    }, 1000 );
}

function displayTable()
{
    let size = parseInt( document.getElementById( 'nprocesses' ).value );

    if ( size <= 0 || size > 10 )
    {
        showToast( 'Please enter a number between 1 and 10', 'error' );
        return;
    }

    let table = `<table class="data-table">
        <thead>
            <tr>
                <th>Process ID</th>
                <th>Process Size (KB)</th>
            </tr>
        </thead>
        <tbody>`;

    for ( let i = 0; i < size; i++ )
    {
        table += `<tr class="fade-in" style="animation-delay: ${i * 0.1}s">
            <td class="td">P${i + 1}</td>
            <td><input type="number" min="1" id="processSize${i + 1}" placeholder="Size in KB"></td>
        </tr>`;
    }

    table += `</tbody></table>`;

    document.getElementById( 'processInputTable' ).innerHTML = table;

    const saveData = `<button class="btn primary animate-pulse">
        <i class="fas fa-play"></i> Run Simulation
    </button>`;

    document.getElementById( 'processesInput' ).innerHTML = saveData;
    showToast( 'Process table created successfully!', 'success' );
}

function saveDataProcess()
{
    const size = parseInt( document.getElementById( 'nprocesses' ).value );

    let isValid = true;
    let invalidFields = [];

    processes = [];

    for ( let i = 0; i < size; i++ )
    {
        const sizeInput = document.getElementById( `processSize${i + 1}` );
        const processSize = parseInt( sizeInput.value );

        if ( isNaN( processSize ) || processSize <= 0 )
        {
            isValid = false;
            invalidFields.push( `P${i + 1}` );
            sizeInput.classList.add( 'error' );
        } else
        {
            sizeInput.classList.remove( 'error' );

            let process = {};
            process.processId = "P" + ( i + 1 );
            process.processSize = processSize;
            processes.push( process );
        }
    }

    if ( !isValid )
    {
        showToast( `Please enter valid sizes for processes: ${invalidFields.join( ', ' )}`, 'error' );
        return;
    }

    simulationActive = true;
    initializeCharts();
    runSimulation();

    document.querySelector( '[data-tab="visualization"]' ).click();
    showToast( 'Simulation started!', 'success' );
}

function initializeCharts()
{
    chart2 = `<div class="memory-blocks">`;
    chart3 = `<div class="memory-blocks">`;
    chart4 = `<div class="memory-blocks">`;
    chart5 = `<div class="memory-blocks">`;

    for ( let i = 0; i < holes.length; i++ )
    {
        chart2 += `<div class="memory-block">
            <div class="hole" id="F${holes[ i ].holeId}">${holes[ i ].holeSize} KB</div>
            <div class="processes-container" id="FF${holes[ i ].holeId}"></div>
            <div class="hole-id">H${i + 1}</div>
        </div>`;

        if ( i != holes.length - 1 ) chart2 += `<div class="memory-separator">•••</div>`;

        chart3 += `<div class="memory-block">
            <div class="hole" id="N${holes[ i ].holeId}">${holes[ i ].holeSize} KB</div>
            <div class="processes-container" id="NF${holes[ i ].holeId}"></div>
            <div class="hole-id">H${i + 1}</div>
        </div>`;

        if ( i != holes.length - 1 ) chart3 += `<div class="memory-separator">•••</div>`;

        chart4 += `<div class="memory-block">
            <div class="hole" id="B${holes[ i ].holeId}">${holes[ i ].holeSize} KB</div>
            <div class="processes-container" id="BF${holes[ i ].holeId}"></div>
            <div class="hole-id">H${i + 1}</div>
        </div>`;

        if ( i != holes.length - 1 ) chart4 += `<div class="memory-separator">•••</div>`;

        chart5 += `<div class="memory-block">
            <div class="hole" id="W${holes[ i ].holeId}">${holes[ i ].holeSize} KB</div>
            <div class="processes-container" id="WF${holes[ i ].holeId}"></div>
            <div class="hole-id">H${i + 1}</div>
        </div>`;

        if ( i != holes.length - 1 ) chart5 += `<div class="memory-separator">•••</div>`;
    }

    chart2 += `</div>`;
    chart3 += `</div>`;
    chart4 += `</div>`;
    chart5 += `</div>`;

    document.getElementById( 'fgaintchart' ).innerHTML = chart2;
    document.getElementById( 'ngaintchart' ).innerHTML = chart3;
    document.getElementById( 'bgaintchart' ).innerHTML = chart4;
    document.getElementById( 'wgaintchart' ).innerHTML = chart5;

    document.getElementById( 'ff-steps' ).innerHTML = '<div class="step-container"><h4>Process Allocation Steps</h4><div class="steps"></div></div>';
    document.getElementById( 'nf-steps' ).innerHTML = '<div class="step-container"><h4>Process Allocation Steps</h4><div class="steps"></div></div>';
    document.getElementById( 'bf-steps' ).innerHTML = '<div class="step-container"><h4>Process Allocation Steps</h4><div class="steps"></div></div>';
    document.getElementById( 'wf-steps' ).innerHTML = '<div class="step-container"><h4>Process Allocation Steps</h4><div class="steps"></div></div>';
}

function runSimulation()
{
    ana = [];

    runFirstFit();
    runNextFit();
    runBestFit();
    runWorstFit();

    document.getElementById( "analysis" ).classList.remove( "hidden" );

    const resultTable = generateResultTable();
    document.getElementById( 'outputTable' ).innerHTML = resultTable;

    generateAnalysis();
    createComparisonChart();
}

function runFirstFit()
{
    notComplete = [];
    holes = JSON.parse( JSON.stringify( cpyHoles ) );
    const stepsContainer = document.querySelector( '#ff-steps .steps' );
    stepsContainer.innerHTML = '';

    for ( let i = 0; i < processes.length; i++ )
    {
        let diff, idx = -1, j;
        let step = document.createElement( 'div' );
        step.className = 'step';

        for ( j = 0; j < holes.length; j++ )
        {
            diff = holes[ j ].holeSize - processes[ i ].processSize;
            if ( diff >= 0 )
            {
                idx = j;
                holes[ idx ].holeSize -= processes[ i ].processSize;

                let fill = document.getElementById( `F${holes[ idx ].holeId}` );
                fill.innerText = `${holes[ idx ].holeSize} KB`;

                let div = document.getElementById( `FF${holes[ idx ].holeId}` );
                let child = document.createElement( "div" );
                child.classList.add( 'process' );
                child.classList.add( `p${i + 1}` );
                child.innerText = `P${i + 1}`;
                div.appendChild( child );

                step.innerHTML = `<div class="step-number">${i + 1}</div>
                    <div class="step-content">
                        <span class="process-label p${i + 1}">P${i + 1} (${processes[ i ].processSize} KB)</span> 
                        allocated to 
                        <span class="hole-label">H${idx + 1}</span>
                        <div class="step-details">Remaining space: ${holes[ idx ].holeSize} KB</div>
                    </div>`;

                break;
            }
        }

        if ( idx !== j )
        {
            notComplete.push( `P${i + 1}` );
            step.innerHTML = `<div class="step-number">${i + 1}</div>
                <div class="step-content">
                    <span class="process-label p${i + 1}">P${i + 1} (${processes[ i ].processSize} KB)</span>
                    <span class="not-allocated">NOT ALLOCATED</span>
                    <div class="step-details">No suitable hole found</div>
                </div>`;
        }

        stepsContainer.appendChild( step );

        setTimeout( () =>
        {
            step.classList.add( 'active' );
        }, 100 );
    }

    calculateAnalysis( "FirstFit" );
}

function runNextFit()
{
    notComplete = [];
    holes = JSON.parse( JSON.stringify( cpyHoles ) );
    const stepsContainer = document.querySelector( '#nf-steps .steps' );
    stepsContainer.innerHTML = '';

    let j = 0, prevIdx = 0;

    for ( let i = 0; i < processes.length; i++ )
    {
        let diff;
        j = prevIdx;
        let allocated = false;
        let step = document.createElement( 'div' );
        step.className = 'step';

        let startPosition = j + 1;
        if ( startPosition > holes.length ) startPosition = 1;

        let attemptsText = '';

        for ( let attempts = 0; attempts < holes.length; attempts++ )
        {
            diff = holes[ j ].holeSize - processes[ i ].processSize;

            attemptsText += `<div>Tried H${j + 1}: ${diff >= 0 ? 'Suitable' : 'Too small'}</div>`;

            if ( diff >= 0 )
            {
                prevIdx = j;
                holes[ j ].holeSize -= processes[ i ].processSize;

                let fill = document.getElementById( `N${holes[ j ].holeId}` );
                fill.innerText = `${holes[ j ].holeSize} KB`;

                let div = document.getElementById( `NF${holes[ j ].holeId}` );
                let child = document.createElement( "div" );
                child.classList.add( 'process' );
                child.classList.add( `p${i + 1}` );
                child.innerText = `P${i + 1}`;
                div.appendChild( child );

                step.innerHTML = `<div class="step-number">${i + 1}</div>
                    <div class="step-content">
                        <span class="process-label p${i + 1}">P${i + 1} (${processes[ i ].processSize} KB)</span> 
                        allocated to 
                        <span class="hole-label">H${j + 1}</span>
                        <div class="step-details">Starting from position: H${startPosition}</div>
                        <div class="step-details">Remaining space: ${holes[ j ].holeSize} KB</div>
                    </div>`;

                allocated = true;
                break;
            }

            j = ( j + 1 ) % holes.length;
            if ( j === prevIdx && attempts > 0 ) break;
        }

        if ( !allocated )
        {
            notComplete.push( `P${i + 1}` );
            step.innerHTML = `<div class="step-number">${i + 1}</div>
                <div class="step-content">
                    <span class="process-label p${i + 1}">P${i + 1} (${processes[ i ].processSize} KB)</span>
                    <span class="not-allocated">NOT ALLOCATED</span>
                    <div class="step-details">Starting from position: H${startPosition}</div>
                    <div class="step-details">No suitable hole found after full search</div>
                </div>`;
        }

        stepsContainer.appendChild( step );

        setTimeout( () =>
        {
            step.classList.add( 'active' );
        }, 100 );
    }

    calculateAnalysis( "NextFit" );
}

function runBestFit()
{
    notComplete = [];
    holes = JSON.parse( JSON.stringify( cpyHoles ) );
    const stepsContainer = document.querySelector( '#bf-steps .steps' );
    stepsContainer.innerHTML = '';

    for ( let i = 0; i < processes.length; i++ )
    {
        let min = Infinity, idx = -1;
        let step = document.createElement( 'div' );
        step.className = 'step';

        let attemptsText = '';

        for ( let j = 0; j < holes.length; j++ )
        {
            let diff = holes[ j ].holeSize - processes[ i ].processSize;

            attemptsText += `<div>H${j + 1}: ${diff >= 0 ? diff + ' KB remaining' : 'Too small'}</div>`;

            if ( diff >= 0 && diff < min )
            {
                min = diff;
                idx = j;
            }
        }

        if ( min != Infinity )
        {
            holes[ idx ].holeSize -= processes[ i ].processSize;

            let fill = document.getElementById( `B${holes[ idx ].holeId}` );
            fill.innerText = `${holes[ idx ].holeSize} KB`;

            let div = document.getElementById( `BF${holes[ idx ].holeId}` );
            let child = document.createElement( "div" );
            child.classList.add( 'process' );
            child.classList.add( `p${i + 1}` );
            child.innerText = `P${i + 1}`;
            div.appendChild( child );

            step.innerHTML = `<div class="step-number">${i + 1}</div>
                <div class="step-content">
                    <span class="process-label p${i + 1}">P${i + 1} (${processes[ i ].processSize} KB)</span> 
                    allocated to 
                    <span class="hole-label">H${idx + 1}</span> (Best fit)
                    <div class="step-details">Remaining space: ${holes[ idx ].holeSize} KB</div>
                </div>`;
        } else
        {
            notComplete.push( `P${i + 1}` );
            step.innerHTML = `<div class="step-number">${i + 1}</div>
                <div class="step-content">
                    <span class="process-label p${i + 1}">P${i + 1} (${processes[ i ].processSize} KB)</span>
                    <span class="not-allocated">NOT ALLOCATED</span>
                    <div class="step-details">No suitable hole found</div>
                </div>`;
        }

        stepsContainer.appendChild( step );

        setTimeout( () =>
        {
            step.classList.add( 'active' );
        }, 100 );
    }

    calculateAnalysis( "BestFit" );
}

function runWorstFit()
{
    notComplete = [];
    holes = JSON.parse( JSON.stringify( cpyHoles ) );
    const stepsContainer = document.querySelector( '#wf-steps .steps' );
    stepsContainer.innerHTML = '';

    for ( let i = 0; i < processes.length; i++ )
    {
        let max = -1, idx = -1;
        let step = document.createElement( 'div' );
        step.className = 'step';

        for ( let j = 0; j < holes.length; j++ )
        {
            if ( holes[ j ].holeSize > max )
            {
                max = holes[ j ].holeSize;
                idx = j;
            }
        }

        if ( max >= processes[ i ].processSize )
        {
            holes[ idx ].holeSize -= processes[ i ].processSize;

            let fill = document.getElementById( `W${holes[ idx ].holeId}` );
            fill.innerText = `${holes[ idx ].holeSize} KB`;

            let div = document.getElementById( `WF${holes[ idx ].holeId}` );
            let child = document.createElement( "div" );
            child.classList.add( 'process' );
            child.classList.add( `p${i + 1}` );
            child.innerText = `P${i + 1}`;
            div.appendChild( child );

            step.innerHTML = `<div class="step-number">${i + 1}</div>
                <div class="step-content">
                    <span class="process-label p${i + 1}">P${i + 1} (${processes[ i ].processSize} KB)</span> 
                    allocated to 
                    <span class="hole-label">H${idx + 1}</span> (Largest hole)
                    <div class="step-details">Remaining space: ${holes[ idx ].holeSize} KB</div>
                </div>`;
        } else
        {
            notComplete.push( `P${i + 1}` );
            step.innerHTML = `<div class="step-number">${i + 1}</div>
                <div class="step-content">
                    <span class="process-label p${i + 1}">P${i + 1} (${processes[ i ].processSize} KB)</span>
                    <span class="not-allocated">NOT ALLOCATED</span>
                    <div class="step-details">No suitable hole found</div>
                </div>`;
        }

        stepsContainer.appendChild( step );

        setTimeout( () =>
        {
            step.classList.add( 'active' );
        }, 100 );
    }

    calculateAnalysis( "WorstFit" );
}

function calculateAnalysis( name )
{
    let min = Infinity, max = -1, sum = 0;
    for ( let i = 0; i < holes.length; i++ )
    {
        sum += holes[ i ].holeSize;
        if ( holes[ i ].holeSize > 0 && holes[ i ].holeSize < min ) min = holes[ i ].holeSize;
        if ( holes[ i ].holeSize > max ) max = holes[ i ].holeSize;
    }

    if ( min == Infinity ) min = 0;

    let analysis = {};
    analysis.name = name;
    analysis.totalHole = sum;
    analysis.minHole = min;
    analysis.maxHole = max;
    analysis.notAllotted = notComplete.length > 0 ? notComplete : 0;
    analysis.fragmentation = calculateFragmentation( holes );
    analysis.efficiency = calculateEfficiency( holes, cpyHoles );

    ana.push( analysis );
}

function calculateFragmentation( currentHoles )
{
    let usableSpace = 0;
    let totalFreeSpace = 0;

    for ( let i = 0; i < currentHoles.length; i++ )
    {
        totalFreeSpace += currentHoles[ i ].holeSize;

        let maxPossibleProcess = -1;
        for ( let j = 0; j < processes.length; j++ )
        {
            if ( processes[ j ].processSize <= currentHoles[ i ].holeSize && processes[ j ].processSize > maxPossibleProcess )
            {
                maxPossibleProcess = processes[ j ].processSize;
            }
        }

        if ( maxPossibleProcess > 0 )
        {
            usableSpace += currentHoles[ i ].holeSize;
        }
    }

    if ( totalFreeSpace === 0 ) return 0;
    return Math.round( ( ( totalFreeSpace - usableSpace ) / totalFreeSpace ) * 100 );
}

function calculateEfficiency( currentHoles, originalHoles )
{
    let originalSpace = 0;
    let remainingSpace = 0;

    for ( let i = 0; i < originalHoles.length; i++ )
    {
        originalSpace += originalHoles[ i ].holeSize;
    }

    for ( let i = 0; i < currentHoles.length; i++ )
    {
        remainingSpace += currentHoles[ i ].holeSize;
    }

    return Math.round( ( ( originalSpace - remainingSpace ) / originalSpace ) * 100 );
}

function generateResultTable()
{
    let resultTable = `
    <table class="result-table">
        <thead>
            <tr>
                <th>Algorithm</th>
                <th>Total Free Space (KB)</th>
                <th>Max Hole (KB)</th>
                <th>Min Hole (KB)</th>
                <th>Fragmentation (%)</th>
                <th>Efficiency (%)</th>
                <th>Not Allocated</th>
            </tr>
        </thead>
        <tbody>`;

    for ( let i = 0; i < ana.length; i++ )
    {
        resultTable += `
        <tr class="fade-in" style="animation-delay: ${i * 0.15}s">
            <td>${ana[ i ].name}</td>
            <td>${ana[ i ].totalHole}</td>
            <td>${ana[ i ].maxHole}</td>
            <td>${ana[ i ].minHole}</td>
            <td>${ana[ i ].fragmentation}%</td>
            <td>${ana[ i ].efficiency}%</td>
            <td>${Array.isArray( ana[ i ].notAllotted ) ? ana[ i ].notAllotted.join( ', ' ) : ana[ i ].notAllotted}</td>
        </tr>`;
    }

    resultTable += `</tbody></table>`;
    return resultTable;
}

function generateAnalysis()
{
    let bestAlgo = findBestAlgorithm();

    let analysisHtml = `
    <div class="analysis-results">
        <div class="recommendation">
            <div class="recommendation-header">
                <i class="fas fa-award"></i> Recommended Algorithm
            </div>
            <div class="recommendation-content">
                <h4>${bestAlgo.name}</h4>
                <p>${bestAlgo.reason}</p>
            </div>
        </div>
        <div class="metrics">
            <div class="metric">
                <div class="metric-value">${bestAlgo.efficiency}%</div>
                <div class="metric-label">Memory Utilization</div>
            </div>
            <div class="metric">
                <div class="metric-value">${bestAlgo.fragmentation}%</div>
                <div class="metric-label">Fragmentation</div>
            </div>
            <div class="metric">
                <div class="metric-value">${processes.length - ( Array.isArray( bestAlgo.notAllotted ) ? bestAlgo.notAllotted.length : 0 )}</div>
                <div class="metric-label">Processes Allocated</div>
            </div>
        </div>
    </div>`;

    document.getElementById( 'analysisResult' ).innerHTML = analysisHtml;
}

function findBestAlgorithm()
{
    let minNotAllocated = Infinity;
    let candidates = [];

    for ( let i = 0; i < ana.length; i++ )
    {
        const notAllocatedCount = Array.isArray( ana[ i ].notAllotted ) ? ana[ i ].notAllotted.length : 0;

        if ( notAllocatedCount < minNotAllocated )
        {
            minNotAllocated = notAllocatedCount;
            candidates = [ i ];
        } else if ( notAllocatedCount === minNotAllocated )
        {
            candidates.push( i );
        }
    }

    if ( candidates.length === 1 )
    {
        return {
            name: ana[ candidates[ 0 ] ].name,
            efficiency: ana[ candidates[ 0 ] ].efficiency,
            fragmentation: ana[ candidates[ 0 ] ].fragmentation,
            notAllotted: ana[ candidates[ 0 ] ].notAllotted,
            reason: `${ana[ candidates[ 0 ] ].name} allocates the most processes with ${ana[ candidates[ 0 ] ].efficiency}% memory utilization.`
        };
    }

    let maxEfficiency = -1;
    let bestCandidate = -1;

    for ( let i = 0; i < candidates.length; i++ )
    {
        if ( ana[ candidates[ i ] ].efficiency > maxEfficiency )
        {
            maxEfficiency = ana[ candidates[ i ] ].efficiency;
            bestCandidate = candidates[ i ];
        }
    }

    return {
        name: ana[ bestCandidate ].name,
        efficiency: ana[ bestCandidate ].efficiency,
        fragmentation: ana[ bestCandidate ].fragmentation,
        notAllotted: ana[ bestCandidate ].notAllotted,
        reason: `${ana[ bestCandidate ].name} provides the best memory utilization (${ana[ bestCandidate ].efficiency}%) among algorithms that allocate the same number of processes.`
    };
}

function createComparisonChart()
{
    const ctx = document.getElementById( 'comparisonChart' ).getContext( '2d' );

    if ( comparisonChart )
    {
        comparisonChart.destroy();
    }

    const labels = ana.map( item => item.name.replace( 'Fit', ' Fit' ) );
    const efficiencyData = ana.map( item => item.efficiency );
    const fragmentationData = ana.map( item => item.fragmentation );

    comparisonChart = new Chart( ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Memory Utilization (%)',
                    data: efficiencyData,
                    backgroundColor: 'rgba(54, 162, 235, 0.7)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                },
                {
                    label: 'Fragmentation (%)',
                    data: fragmentationData,
                    backgroundColor: 'rgba(255, 99, 132, 0.7)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    title: {
                        display: true,
                        text: 'Percentage (%)'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Allocation Algorithms'
                    }
                }
            },
            plugins: {
                legend: {
                    position: 'top',
                },
                tooltip: {
                    callbacks: {
                        label: function ( context )
                        {
                            let label = context.dataset.label || '';
                            if ( label )
                            {
                                label += ': ';
                            }
                            label += context.parsed.y + '%';
                            return label;
                        }
                    }
                }
            }
        }
    } );

    setTimeout( () =>
    {
        document.querySelector( '[data-tab="results"]' ).click();
    }, 2000 );
}